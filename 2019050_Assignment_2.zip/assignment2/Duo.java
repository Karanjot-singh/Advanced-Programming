package assignment2;

public class Duo {
	private Food item;
	private Food itemOld;

	public Duo(Food item, Food itemOld) {
		super();
		this.item = item;
		this.itemOld = itemOld;
	}

	public Food getItem() {
		return item;
	}

	public Food getItemOld() {
		return itemOld;
	}

}
